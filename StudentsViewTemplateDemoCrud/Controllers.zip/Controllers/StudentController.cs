﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using StudentsViewTemplateDemoCrud.Models;

namespace StudentsViewTemplateDemoCrud.Controllers
{
    [RoutePrefix("students")]
    public class StudentController : Controller
    {
        // GET: Student

        static List<Student> students = new List<Student>()
        {
            new Student(){ Id = 1,
            Name="Allen",
                Age=34,
            Address=new Address(){
                Id=101,
                Country="India",
                State="Goa",
                City="Panjim"
            }
            },
            new Student(){
            Id=2,
            Name="Mary",
                Age=42,
            Address=new Address(){
                Id=102,
                Country="India",
                State="Punjab",
                City="Mohali"
            }
            },

             new Student(){
            Id=3,
            Name="Rosh",
                Age=2,
            Address=new Address(){
                Id=103,
                Country="India",
                State="MadhyaPradesh",
                City="Indore"
            }
            },

              new Student(){
            Id=4,
            Name="Mars",
                Age=33,
            Address=new Address(){
                Id=104,
                Country="Russia",
                State="Sakha Republic",
                City="Moscow"
            }
            },

               new Student(){
            Id=5,
            Name="Lara",
                Age=87,
            Address=new Address(){
                Id=105,
                Country="Spain",
                State="Catalonia",
                City="Barcelona"
            }
            }
    };

        [Route("")] //empty means default
        public ActionResult GetAllStudents()
        {
            var data = students;
            return View(data);
        }

        [Route("{id:int}")]
        public ActionResult GetStudentById(int id)
        {
            var student = students.FirstOrDefault(x => x.Id == id);
            return View(student);
        }
        [Route("address/{id}")]
        public ActionResult GetAddressOfStudentById(int id)
        {
            var studentAddress = students.Where(st => st.Id == id).Select(st => st.Address).FirstOrDefault();
            return View(studentAddress);
        }

        [HttpGet]
        public ActionResult Delete(int id)
        {
            var deleteStudent = students.FirstOrDefault(students => students.Id == id);
            students.Remove(deleteStudent);
            return View(deleteStudent);
        }

        [HttpDelete]
        public ActionResult Delete()
        {
            return View();
        }


        [HttpGet]
        public ActionResult Edit()
        {
            return View();

        }
        [HttpPut]
        public ActionResult Edit(Student editStudent)
        {
            var updateStudent = students.FirstOrDefault(s=>s.Id == editStudent.Id);
            updateStudent.Name = editStudent.Name;
            updateStudent.Age = editStudent.Age;
            updateStudent.Address = editStudent.Address;
            return View();  
        }
       
        [HttpGet]
        public ActionResult Details(int id)
        {
            var student = students.FirstOrDefault(x => x.Id == id);
            return View(student);
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Student student)
        {
            students.Add(student);
            return RedirectToAction("GetAllStudents");
           
        }

        //[HttpGet]
        //public ActionResult EditAddress()
        //{
        //    return View();
        //}

        //[HttpPut]
        //public ActionResult EditAddress(Address address)
        //{

        //}





    }
}